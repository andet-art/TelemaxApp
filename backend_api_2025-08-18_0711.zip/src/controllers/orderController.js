import { createOrderWithItems, getUserOrders, getOrderItems } from '../models/orderModel.js';
export const createOrder = async (req,res)=>{
  try{
    const user_id = req.user?.id;
    const { full_name, email, phone, address, notes, items } = req.body;
    if(!user_id) return res.status(401).json({error:'Unauthorized'});
    if(!full_name||!email||!address) return res.status(422).json({error:'Missing required fields'});
    if(!Array.isArray(items)||!items.length) return res.status(422).json({error:'No items'});
    const result = await createOrderWithItems({ user_id, full_name, email, phone, address, notes, items });
    res.status(201).json({ message:'Order created', ...result });
  }catch(e){ res.status(400).json({error:e.message}); }
};
export const listMyOrders = async (req,res)=>{
  try{ const orders = await getUserOrders(req.user.id); res.json(orders); }
  catch(e){ res.status(500).json({error:e.message}); }
};
export const getOneOrder = async (req,res)=>{
  try{
    const user_id=req.user.id, orderId=Number(req.params.id);
    const my = await getUserOrders(user_id);
    if(!my.find(o=>o.id===orderId)) return res.status(404).json({error:'Not found'});
    const items = await getOrderItems(orderId);
    res.json({ order: my.find(o=>o.id===orderId), items });
  }catch(e){ res.status(500).json({error:e.message}); }
};
