import express from 'express';
import pool from '../config/db.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = express.Router();
router.use(requireAuth, requireAdmin);

// list all orders (newest first)
router.get('/orders', async (_req,res)=>{
  try {
    const [rows] = await pool.query('SELECT * FROM orders ORDER BY created_at DESC');
    res.json(rows);
  } catch(e){ res.status(500).json({error:e.message}); }
});

// get single order + items
router.get('/orders/:id', async (req,res)=>{
  try {
    const id = Number(req.params.id);
    const [[order]] = await pool.query('SELECT * FROM orders WHERE id=?',[id]);
    if(!order) return res.status(404).json({error:'Not found'});
    const [items] = await pool.query(
      `SELECT oi.*, p.name AS product_name, s.name AS starter_name, r.name AS ring_name, t.name AS top_name
       FROM order_items oi
       LEFT JOIN products p ON p.id=oi.product_id
       LEFT JOIN parts s ON s.id=oi.starter_id
       LEFT JOIN parts r ON r.id=oi.ring_id
       LEFT JOIN parts t ON t.id=oi.top_id
       WHERE oi.order_id=?`, [id]);
    res.json({order, items});
  } catch(e){ res.status(500).json({error:e.message}); }
});

// update order status
router.patch('/orders/:id/status', async (req,res)=>{
  try {
    const id = Number(req.params.id);
    const { status } = req.body; // Pending, Processing, Shipped, Delivered, Cancelled
    const allowed = new Set(['Pending','Processing','Shipped','Delivered','Cancelled']);
    if(!allowed.has(status)) return res.status(422).json({error:'Invalid status'});
    const [r] = await pool.query('UPDATE orders SET status=? WHERE id=?',[status, id]);
    if(!r.affectedRows) return res.status(404).json({error:'Not found'});
    res.json({message:'Status updated'});
  } catch(e){ res.status(500).json({error:e.message}); }
});

export default router;
