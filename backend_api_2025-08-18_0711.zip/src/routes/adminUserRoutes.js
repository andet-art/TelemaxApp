import express from 'express';
import pool from '../config/db.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';

const router = express.Router();
router.use(requireAuth, requireAdmin);

// list users
router.get('/users', async (_req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id,email,role,first_name,last_name,locked,created_at,last_active FROM users ORDER BY id DESC'
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// lock/unlock user
router.patch('/users/:id/lock', async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { locked } = req.body;
    const [r] = await pool.query('UPDATE users SET locked=? WHERE id=?', [locked ? 1 : 0, id]);
    if (!r.affectedRows) return res.status(404).json({ error: 'Not found' });
    res.json({ ok: true });
  } catch (e) { res.status(400).json({ error: e.message }); }
});

export default router;
