import express from 'express';
import pool from '../config/db.js';
const router = express.Router();

router.get('/', async (_req, res) => {
  try {
    const [rows] = await pool.query(
      'SELECT id,name,description,price,version,image_url,starter_id,ring_id,top_id FROM products ORDER BY id DESC'
    );
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/parts', async (_req, res) => {
  try {
    const [rows] = await pool.query('SELECT id,type,name,price,image_url FROM parts ORDER BY type,id');
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

export default router;
