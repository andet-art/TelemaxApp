import express from 'express';
import pool from '../config/db.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = express.Router();
router.use(requireAuth, requireAdmin);

router.get('/stats', async (_req,res)=>{
  try{
    const [[a]] = await pool.query('SELECT COUNT(*) users FROM users');
    const [[b]] = await pool.query('SELECT COUNT(*) orders FROM orders');
    const [[c]] = await pool.query('SELECT IFNULL(SUM(total_price),0) revenue FROM orders');
    res.json({ users:a.users, orders:b.orders, revenue:Number(c.revenue) });
  }catch(e){ res.status(500).json({error:e.message}); }
});
export default router;
