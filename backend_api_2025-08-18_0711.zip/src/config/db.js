import 'dotenv/config';
import mysql from 'mysql2/promise';

// Force IPv4 + sane defaults even if env missing
const host = process.env.DB_HOST || '127.0.0.1';
const port = Number(process.env.DB_PORT || 3306);

const pool = mysql.createPool({
  host,
  port,
  user: process.env.DB_USER,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  waitForConnections: true,
  connectionLimit: 10,
  queueLimit: 0
});

// Optional: quick startup check (logs once)
(async () => {
  try {
    const conn = await pool.getConnection();
    console.log(`✅ MySQL pool connected to ${host}:${port}`);
    conn.release();
  } catch (e) {
    console.error('❌ MySQL connection failed:', e.message);
  }
})();

export default pool;
