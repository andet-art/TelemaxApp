import helmet from 'helmet';
import cors from 'cors';
import compression from 'compression';
import morgan from 'morgan';
import rateLimit from 'express-rate-limit';

export const applySecurity = (app) => {
  app.set('trust proxy', 1);
  app.use(helmet());
  app.use(compression());
  app.use(morgan(process.env.NODE_ENV === 'production' ? 'combined' : 'dev'));
  app.use(cors({ origin: process.env.CORS_ORIGIN.split(','), credentials: true }));

  const limiter = rateLimit({
    windowMs: 15 * 60 * 1000,
    limit: 100,
    standardHeaders: true
  });
  app.use('/api/auth', limiter);
};
