import express from 'express';
import { requireAuth } from '../middleware/auth.js';
import { createOrder, listMyOrders, getOneOrder } from '../controllers/orderController.js';
const router = express.Router();
router.use(requireAuth);
router.post('/', createOrder);
router.get('/', listMyOrders);
router.get('/:id', getOneOrder);
export default router;
