import express from 'express';
import pool from '../config/db.js';
import { requireAuth, requireAdmin } from '../middleware/auth.js';
const router = express.Router();
router.use(requireAuth, requireAdmin);

// PRODUCTS
router.post('/products', async (req,res)=>{ try{
  const { name, description=null, price, version=null, image_url=null, starter_id=null, ring_id=null, top_id=null } = req.body;
  const [r]=await pool.query(`INSERT INTO products (name,description,price,version,image_url,starter_id,ring_id,top_id) VALUES (?,?,?,?,?,?,?,?)`,
    [name,description,price,version,image_url,starter_id,ring_id,top_id]);
  res.status(201).json({ id:r.insertId });
}catch(e){ res.status(400).json({error:e.message}); }});

router.put('/products/:id', async (req,res)=>{ try{
  const id=Number(req.params.id);
  const fields=['name','description','price','version','image_url','starter_id','ring_id','top_id'];
  const set=[]; const vals=[];
  for(const f of fields){ if(req.body[f]!==undefined){ set.push(`${f}=?`); vals.push(req.body[f]); } }
  if(!set.length) return res.status(422).json({error:'No fields'});
  vals.push(id);
  const [r]=await pool.query(`UPDATE products SET ${set.join(', ')} WHERE id=?`, vals);
  if(!r.affectedRows) return res.status(404).json({error:'Not found'}); res.json({ok:true});
}catch(e){ res.status(400).json({error:e.message}); }});

router.delete('/products/:id', async (req,res)=>{ try{
  const [r]=await pool.query(`DELETE FROM products WHERE id=?`, [Number(req.params.id)]);
  if(!r.affectedRows) return res.status(404).json({error:'Not found'}); res.json({ok:true});
}catch(e){ res.status(400).json({error:e.message}); }});

// PARTS
router.post('/parts', async (req,res)=>{ try{
  const { type, name, price=0, image_url=null } = req.body;
  const [r]=await pool.query(`INSERT INTO parts (type,name,price,image_url) VALUES (?,?,?,?)`,[type,name,price,image_url]);
  res.status(201).json({ id:r.insertId });
}catch(e){ res.status(400).json({error:e.message}); }});

router.put('/parts/:id', async (req,res)=>{ try{
  const id=Number(req.params.id);
  const fields=['type','name','price','image_url'];
  const set=[]; const vals=[];
  for(const f of fields){ if(req.body[f]!==undefined){ set.push(`${f}=?`); vals.push(req.body[f]); } }
  if(!set.length) return res.status(422).json({error:'No fields'});
  vals.push(id);
  const [r]=await pool.query(`UPDATE parts SET ${set.join(', ')} WHERE id=?`, vals);
  if(!r.affectedRows) return res.status(404).json({error:'Not found'}); res.json({ok:true});
}catch(e){ res.status(400).json({error:e.message}); }});

router.delete('/parts/:id', async (req,res)=>{ try{
  const [r]=await pool.query(`DELETE FROM parts WHERE id=?`, [Number(req.params.id)]);
  if(!r.affectedRows) return res.status(404).json({error:'Not found'}); res.json({ok:true});
}catch(e){ res.status(400).json({error:e.message}); }});

export default router;
